const LIVR = require('livr');
const rules = {
};
module.exports = (args: { data: Object }) => {
    console.log("record defaults");
    const validator = new LIVR.Validator(rules).prepare();
    const result    = validator.validate(args.data);
    if (result) {
        console.log('ALL OK');
    } else {
        console.log(validator.getErrors());
        return Promise.reject(validator.getErrors());
    }
};