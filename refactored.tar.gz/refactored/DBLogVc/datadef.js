module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fEventType: { public: true, type: 'BIGINT' },
     fEventDate: { public: true, type: 'DATE' },
     fEventTime: { public: true, type: 'TIME' },
     fDBSize: { public: true, type: 'BIGINT' },
     fFreeDiskSpace: { public: true, type: 'BIGINT' },
     fExtraSize: { public: true, type: 'BIGINT' },
     fExtraInfo: { public: true, type: 'TEXT' } },
  indexes: 
   { MainKeyIndex208: 
      { fields: [ 'fEventType', 'fEventDate', 'fEventTime' ],
        indicesType: 'UNIQUE' } } }