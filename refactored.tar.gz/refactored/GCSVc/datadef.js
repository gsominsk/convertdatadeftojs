module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fTransDate: { public: true, type: 'DATE' },
     fAmount: { public: true, type: 'DOUBLE' },
     fComment: { public: true, type: 'TEXT' },
     fExpiryDate: { public: true, type: 'DATE' },
     fClosed: { public: true, type: 'INTEGER' },
     fInvSerNr: { public: true, type: 'BIGINT' },
     fBarCode: { public: true, type: 'TEXT' },
     fBalance: { public: true, type: 'DOUBLE' },
     fFileName: { public: true, type: 'TEXT' } },
  indexes: { SerNrIndex422: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }