module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fFileName: { public: true, type: 'TEXT' },
     fTransNr: { public: true, type: 'BIGINT' },
     fIntYc: { public: true, type: 'INTEGER' },
     fTransRow: { public: true, type: 'BIGINT' },
     fBankTRNr: { public: true, type: 'BIGINT' },
     fBankTRDate: { public: true, type: 'DATE' },
     fTransDate: { public: true, type: 'DATE' },
     fTypeRef: { public: true, type: 'TEXT' },
     fSum: { public: true, type: 'DOUBLE' } } }