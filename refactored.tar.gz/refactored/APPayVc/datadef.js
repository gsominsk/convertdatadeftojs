module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fVEPNr: { public: true, type: 'BIGINT' },
     fRVal: { public: true, type: 'DOUBLE' },
     fPayDate: { public: true, type: 'DATE' },
     fVECode: { public: true, type: 'TEXT' },
     fCurncyCode: { public: true, type: 'TEXT' },
     fVEName: { public: true, type: 'TEXT' },
     fBookRVal: { public: true, type: 'DOUBLE' } },
  indexes: { VEPNrIndex27: { fields: [ 'fVEPNr' ], indicesType: 'UNIQUE' } } }