module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fPickingOrder: { public: true, type: 'INTEGER' } } }