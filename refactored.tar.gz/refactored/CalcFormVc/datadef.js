module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fPayCode: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     CalcFormVcMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fFrom: { public: true, type: 'DOUBLE' },
           fTo: { public: true, type: 'DOUBLE' },
           fPercent: { public: true, type: 'DOUBLE' },
           fAmount: { public: true, type: 'DOUBLE' } } } },
  indexes: { PayCodeIndex191: { fields: [ 'fPayCode' ], indicesType: 'UNIQUE' } } }