module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSeqnr: { public: true, type: 'BIGINT' },
     fPLCode: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fArtCode: { public: true, type: 'TEXT' },
     fExVatPrice: { public: true, type: 'DOUBLE' },
     fSalesAcc: { public: true, type: 'TEXT' },
     fCustCode: { public: true, type: 'TEXT' },
     fNoOtherPricing: { public: true, type: 'INTEGER' },
     fVATCode: { public: true, type: 'TEXT' },
     fDonotRecalculate: { public: true, type: 'INTEGER' },
     fCostPrice: { public: true, type: 'DOUBLE' },
     fBBGenTrans: { public: true, type: 'INTEGER' },
     fBBVarAcc: { public: true, type: 'TEXT' } },
  indexes: 
   { PLCodeIndex389: 
      { fields: [ 'fPLCode', 'fArtCode', 'fCustCode' ],
        indicesType: 'UNIQUE' } } }