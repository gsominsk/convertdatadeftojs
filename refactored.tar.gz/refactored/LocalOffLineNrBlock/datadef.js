module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fLastIVCashNr: { public: true, type: 'BIGINT' } } }