module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fExcelStatus: { public: true, type: 'INTEGER' } } }