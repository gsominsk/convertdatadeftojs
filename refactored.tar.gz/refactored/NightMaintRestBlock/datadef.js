module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fAddToDay: { public: true, type: 'INTEGER' },
     fStartTime: { public: true, type: 'TIME' },
     fUpdateStock: { public: true, type: 'INTEGER' } } }