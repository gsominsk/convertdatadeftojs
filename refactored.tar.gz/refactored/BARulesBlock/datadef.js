module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSMS: { public: true, type: 'INTEGER' },
     fSystemMobile: { public: true, type: 'TEXT' },
     fEMail: { public: true, type: 'INTEGER' },
     fSystemeMail: { public: true, type: 'TEXT' } } }