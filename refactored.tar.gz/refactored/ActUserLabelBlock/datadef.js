module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fUserStr1: { public: true, type: 'TEXT' },
     fUserStr2: { public: true, type: 'TEXT' },
     fUserStr3: { public: true, type: 'TEXT' },
     fUserStr4: { public: true, type: 'TEXT' },
     fUserStr5: { public: true, type: 'TEXT' },
     fUserVal1: { public: true, type: 'TEXT' },
     fUserVal2: { public: true, type: 'TEXT' },
     fUserVal3: { public: true, type: 'TEXT' },
     fUserDate1: { public: true, type: 'TEXT' },
     fUserDate2: { public: true, type: 'TEXT' },
     fUserDate3: { public: true, type: 'TEXT' } } }