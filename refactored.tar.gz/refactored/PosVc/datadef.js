module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fLocation: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fPickOrder: { public: true, type: 'BIGINT' },
     fLocArea: { public: true, type: 'TEXT' },
     fWidth: { public: true, type: 'DOUBLE' },
     fHeight: { public: true, type: 'DOUBLE' },
     fDepth: { public: true, type: 'DOUBLE' },
     fMaxWeight: { public: true, type: 'DOUBLE' },
     fStatus: { public: true, type: 'INTEGER' },
     fClosed: { public: true, type: 'INTEGER' } },
  indexes: { MainKeyIndex283: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }