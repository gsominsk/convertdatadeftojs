module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCoef1: { public: true, type: 'INTEGER' },
     fCoef2: { public: true, type: 'INTEGER' },
     fCoef3: { public: true, type: 'INTEGER' },
     fCoef4: { public: true, type: 'INTEGER' },
     fCoef5: { public: true, type: 'INTEGER' },
     fCoef6: { public: true, type: 'INTEGER' },
     fCoef7: { public: true, type: 'INTEGER' },
     fCoef8: { public: true, type: 'INTEGER' },
     fCoef9: { public: true, type: 'INTEGER' },
     fUseEqMachines: { public: true, type: 'INTEGER' },
     fCompressProdFlag: { public: true, type: 'INTEGER' },
     fUseRouteEqMachines: { public: true, type: 'INTEGER' } } }