module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fActiveSHNr: { public: true, type: 'BIGINT' },
     fActiveForkLiftQueNr: { public: true, type: 'BIGINT' },
     fForkLift: { public: true, type: 'TEXT' },
     fPalletCnt: { public: true, type: 'INTEGER' } } }