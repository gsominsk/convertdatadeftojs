module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fUser: { public: true, type: 'TEXT' },
     fDate: { public: true, type: 'DATE' },
     fTime: { public: true, type: 'TIME' },
     fServerDelay: { public: true, type: 'BIGINT' },
     fTotalDelay: { public: true, type: 'BIGINT' } },
  indexes: { SerNrIndex434: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }