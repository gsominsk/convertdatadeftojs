module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fArtCode: { public: true, type: 'TEXT' },
     fLocation: { public: true, type: 'TEXT' },
     fLocOKNr: { public: true, type: 'DOUBLE' },
     fIntYc: { public: true, type: 'INTEGER' },
     fTransNr: { public: true, type: 'BIGINT' },
     fRowNr: { public: true, type: 'INTEGER' },
     fInQuant: { public: true, type: 'DOUBLE' } },
  indexes: 
   { ArtCodeIndex378: 
      { fields: [ 'fArtCode', 'fIntYc', 'fTransNr', 'fRowNr' ],
        indicesType: 'UNIQUE' } } }