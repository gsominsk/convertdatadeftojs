module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fStartDate: { public: true, type: 'DATE' },
     fEndDate: { public: true, type: 'DATE' },
     fComment: { public: true, type: 'TEXT' },
     fPeriodLength: { public: true, type: 'INTEGER' },
     fPeriodType: { public: true, type: 'INTEGER' },
     fPeriodOffset: { public: true, type: 'BIGINT' },
     fPeriodUnits: { public: true, type: 'BIGINT' },
     fOffsetType: { public: true, type: 'INTEGER' },
     fPeriod2Str: { public: true, type: 'TEXT' },
     fReportingPeriodType: { public: true, type: 'INTEGER' } },
  indexes: { CodeIndex771: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }