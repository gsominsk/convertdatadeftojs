module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fFileName: { public: true, type: 'TEXT' },
     fTransNr: { public: true, type: 'BIGINT' },
     fTransDate: { public: true, type: 'DATE' },
     fTransTime: { public: true, type: 'TIME' },
     fSign: { public: true, type: 'TEXT' } },
  indexes: { SerNrIndex376: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }