module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fArtCode: { public: true, type: 'TEXT' },
     fRegDate: { public: true, type: 'DATE' },
     fCurncyCode: { public: true, type: 'TEXT' },
     fDesc: { public: true, type: 'TEXT' },
     fPrice1: { public: true, type: 'DOUBLE' },
     fPrice2: { public: true, type: 'DOUBLE' },
     fPrice3: { public: true, type: 'DOUBLE' },
     fPrice4: { public: true, type: 'DOUBLE' } },
  indexes: 
   { ArtCodeIndex306: 
      { fields: [ 'fArtCode', 'fCurncyCode', 'fRegDate' ],
        indicesType: 'UNIQUE' } } }