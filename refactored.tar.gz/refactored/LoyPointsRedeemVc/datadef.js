module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fLCMLevel: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fAmount: { public: true, type: 'DOUBLE' },
     fPoints: { public: true, type: 'DOUBLE' },
     LoyPointsRedeemVcMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fCodeType: { public: true, type: 'INTEGER' },
           fITCode: { public: true, type: 'TEXT' },
           fAmount: { public: true, type: 'DOUBLE' },
           fPoints: { public: true, type: 'DOUBLE' } } } },
  indexes: { LCMLevelIndex744: { fields: [ 'fLCMLevel' ], indicesType: 'UNIQUE' } } }