module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fWeightCoefficient: { public: true, type: 'DOUBLE' } },
  indexes: { CodeIndex154: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }