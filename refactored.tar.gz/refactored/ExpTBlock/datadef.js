module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fExpDemandSign: { public: true, type: 'INTEGER' },
     fExpRateCostAcc: { public: true, type: 'INTEGER' } } }