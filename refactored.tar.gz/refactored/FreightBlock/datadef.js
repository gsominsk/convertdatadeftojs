module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fFrItem: { public: true, type: 'TEXT' },
     fFrGPPercent: { public: true, type: 'DOUBLE' },
     fUseWeight: { public: true, type: 'INTEGER' } } }