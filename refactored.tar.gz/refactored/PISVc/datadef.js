module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fArtCode: { public: true, type: 'TEXT' },
     fLocation: { public: true, type: 'TEXT' },
     fPosition: { public: true, type: 'TEXT' },
     fInstock: { public: true, type: 'DOUBLE' },
     fInstock2: { public: true, type: 'DOUBLE' },
     fInStockMov: { public: true, type: 'DOUBLE' },
     fLeftQty: { public: true, type: 'DOUBLE' },
     fLocArea: { public: true, type: 'TEXT' },
     fPickOrder: { public: true, type: 'BIGINT' },
     fVariety: { public: true, type: 'TEXT' } },
  indexes: 
   { ArtCodeIndex425: 
      { fields: [ 'fArtCode', 'fPosition', 'fLocation', 'fVariety' ],
        indicesType: 'UNIQUE' } } }