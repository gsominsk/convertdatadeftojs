module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fVATZoneName: { public: true, type: 'TEXT' } } }