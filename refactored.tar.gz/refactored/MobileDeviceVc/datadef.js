module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fSign: { public: true, type: 'TEXT' },
     fMobileNumber: { public: true, type: 'TEXT' },
     fDeviceType: { public: true, type: 'INTEGER' },
     fActiveFlag: { public: true, type: 'INTEGER' },
     fDeviceToken: { public: true, type: 'BIGINT' },
     fBundleIdentifier: { public: true, type: 'TEXT' } },
  indexes: { SerNrIndex666: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }