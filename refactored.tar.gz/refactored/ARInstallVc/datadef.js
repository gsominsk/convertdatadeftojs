module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fInvoiceNr: { public: true, type: 'BIGINT' },
     fRVal: { public: true, type: 'DOUBLE' },
     fDueDate: { public: true, type: 'DATE' },
     fCustCode: { public: true, type: 'TEXT' },
     fARCurncyCode: { public: true, type: 'TEXT' },
     fBookRVal: { public: true, type: 'DOUBLE' },
     fInstallNr: { public: true, type: 'BIGINT' } },
  indexes: { InvoiceNrIndex24: { fields: [ 'fInvoiceNr', 'fDueDate' ], indicesType: 'UNIQUE' } } }