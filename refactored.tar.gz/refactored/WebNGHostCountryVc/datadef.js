module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fHostname: { public: true, type: 'TEXT' },
     fCountry: { public: true, type: 'TEXT' } },
  indexes: { HostnameIndex604: { fields: [ 'fHostname' ], indicesType: 'UNIQUE' } } }