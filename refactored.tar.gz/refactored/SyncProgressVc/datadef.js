module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fVc: { public: true, type: 'TEXT' },
     fSyncToServerPos: { public: true, type: 'BIGINT' },
     fSyncFromServerPos: { public: true, type: 'BIGINT' },
     fSyncToServerDelPos: { public: true, type: 'BIGINT' },
     fSyncFromServerDelPos: { public: true, type: 'BIGINT' } },
  indexes: { MainKeyIndex568: { fields: [ 'fVc' ], indicesType: 'UNIQUE' } } }