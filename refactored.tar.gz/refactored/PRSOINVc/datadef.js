module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fProject: { public: true, type: 'TEXT' },
     fItem: { public: true, type: 'TEXT' },
     fSOSerNr: { public: true, type: 'BIGINT' },
     fSOQty: { public: true, type: 'DOUBLE' },
     fSOVal: { public: true, type: 'DOUBLE' },
     fTransDate: { public: true, type: 'DATE' } },
  indexes: 
   { ProjectIndex183: 
      { fields: [ 'fProject', 'fItem', 'fSOSerNr' ],
        indicesType: 'UNIQUE' } } }