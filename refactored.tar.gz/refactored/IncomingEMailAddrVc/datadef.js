module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fExternalEMail: { public: true, type: 'BIGINT' },
     fMailbox: { public: true, type: 'BIGINT' },
     fMailboxName: { public: true, type: 'TEXT' } },
  indexes: { ExternalEMailIndex702: { fields: [ 'fExternalEMail' ], indicesType: 'UNIQUE' } } }