module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fMaxExtraBeds: { public: true, type: 'BIGINT' },
     fBranchID: { public: true, type: 'TEXT' } },
  indexes: { CodeIndex226: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }