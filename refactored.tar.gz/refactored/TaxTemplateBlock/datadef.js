module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fVATCodeOnTRRows: { public: true, type: 'INTEGER' } } }