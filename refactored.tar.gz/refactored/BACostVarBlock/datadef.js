module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fEmail: { public: true, type: 'INTEGER' },
     fCostVariance: { public: true, type: 'DOUBLE' },
     fTxtCode: { public: true, type: 'TEXT' } } }