module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fPeriods: { public: true, type: 'BIGINT' },
     fRoundOff: { public: true, type: 'INTEGER' },
     fOneConPOPlan: { public: true, type: 'INTEGER' },
     fSortPOPlanRow: { public: true, type: 'INTEGER' },
     fWhatItemsToPut: { public: true, type: 'INTEGER' },
     fOrderBufferDay: { public: true, type: 'BIGINT' },
     fPeriodType: { public: true, type: 'INTEGER' } } }