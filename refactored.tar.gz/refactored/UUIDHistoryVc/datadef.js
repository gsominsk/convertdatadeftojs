module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fForUUID: { public: true, type: 'TEXT' },
     fVcName: { public: true, type: 'TEXT' },
     fHistSeqNo: { public: true, type: 'BIGINT' },
     fOp: { public: true, type: 'INTEGER' },
     fOriginalImage: { public: true, type: 'BIGINT' },
     fDate: { public: true, type: 'DATE' },
     fTime: { public: true, type: 'TIME' },
     fUser: { public: true, type: 'TEXT' } },
  indexes: { ForUUIDIndex569: { fields: [ 'fForUUID', 'fHistSeqNo' ], indicesType: 'UNIQUE' } } }