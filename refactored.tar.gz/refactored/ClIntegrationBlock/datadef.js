module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSkypef: { public: true, type: 'INTEGER' },
     fMacAddressBookf: { public: true, type: 'INTEGER' },
     fBria3f: { public: true, type: 'INTEGER' } } }