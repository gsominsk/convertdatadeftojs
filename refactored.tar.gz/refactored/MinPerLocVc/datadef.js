module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fItemCode: { public: true, type: 'TEXT' },
     fLocation: { public: true, type: 'TEXT' },
     fVECode: { public: true, type: 'TEXT' },
     fMinLevel: { public: true, type: 'DOUBLE' },
     fMaxLevel: { public: true, type: 'DOUBLE' },
     fMinPOQty: { public: true, type: 'DOUBLE' },
     fNormPOQty: { public: true, type: 'DOUBLE' },
     fPosition: { public: true, type: 'TEXT' } },
  indexes: 
   { MainKeyIndex311: 
      { fields: [ 'fItemCode', 'fLocation', 'fPosition' ],
        indicesType: 'UNIQUE' } } }