module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fLookupServIP: { public: true, type: 'TEXT' },
     fLookupServPort: { public: true, type: 'BIGINT' },
     fManualsServIP: { public: true, type: 'TEXT' },
     fServiceShopIP: { public: true, type: 'TEXT' },
     fLookupServHTTPPort: { public: true, type: 'BIGINT' } } }