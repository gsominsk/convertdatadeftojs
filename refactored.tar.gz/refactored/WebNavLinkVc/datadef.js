module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fURL: { public: true, type: 'TEXT' },
     fOpenType: { public: true, type: 'INTEGER' },
     fDescription: { public: true, type: 'TEXT' } },
  indexes: { SerNrIndex663: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }