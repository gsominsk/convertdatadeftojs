module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fDefaultCharge: { public: true, type: 'TEXT' },
     fDefaultSum: { public: true, type: 'DOUBLE' },
     fEnablerDays: { public: true, type: 'BIGINT' } } }