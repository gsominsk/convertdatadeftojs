module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSelCountry: { public: true, type: 'TEXT' },
     fVATLaw: { public: true, type: 'BIGINT' } } }