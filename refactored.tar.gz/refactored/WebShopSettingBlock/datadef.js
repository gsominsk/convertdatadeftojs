module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fObjects: { public: true, type: 'TEXT' } } }