module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fUserCode: { public: true, type: 'TEXT' },
     fSalesGroup: { public: true, type: 'TEXT' },
     SynkGlobalAutoSerVcMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fFileName: { public: true, type: 'TEXT' },
           fNumberSeries: { public: true, type: 'BIGINT' },
           fNrsRangeQty: { public: true, type: 'BIGINT' },
           fNrsMinimum: { public: true, type: 'BIGINT' } } } },
  indexes: 
   { UserCodeIndex814: 
      { fields: [ 'fUserCode', 'fSalesGroup' ],
        indicesType: 'UNIQUE' } } }