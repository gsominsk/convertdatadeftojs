module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fPONr: { public: true, type: 'BIGINT' },
     fOrdRow: { public: true, type: 'BIGINT' },
     fPUQuant: { public: true, type: 'DOUBLE' },
     fPUAmount: { public: true, type: 'DOUBLE' },
     fVIQuant: { public: true, type: 'DOUBLE' },
     fVIAmount: { public: true, type: 'DOUBLE' },
     fDoneQuant: { public: true, type: 'DOUBLE' },
     fDoneAmount: { public: true, type: 'DOUBLE' },
     fPUBaseAmount: { public: true, type: 'DOUBLE' },
     fVIBaseAmount: { public: true, type: 'DOUBLE' } },
  indexes: { MainKeyIndex454: { fields: [ 'fPONr', 'fOrdRow' ], indicesType: 'UNIQUE' } } }