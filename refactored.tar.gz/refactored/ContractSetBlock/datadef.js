module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fUpdateContracts: { public: true, type: 'INTEGER' },
     fCreateRegister: { public: true, type: 'INTEGER' } } }