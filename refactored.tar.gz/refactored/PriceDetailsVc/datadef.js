module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fPrice: { public: true, type: 'DOUBLE' },
     fDescstr: { public: true, type: 'TEXT' },
     fDiscount: { public: true, type: 'DOUBLE' },
     fVatcode: { public: true, type: 'TEXT' },
     fBasepricep: { public: true, type: 'DOUBLE' },
     fSalesacc: { public: true, type: 'TEXT' },
     fTax2code: { public: true, type: 'TEXT' },
     fTax2prc: { public: true, type: 'DOUBLE' },
     fTaxtempletecode: { public: true, type: 'TEXT' } } }