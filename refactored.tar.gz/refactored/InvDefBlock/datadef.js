module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     InvDefBlockMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fLangCode: { public: true, type: 'TEXT' },
           fUserGroup: { public: true, type: 'TEXT' },
           fSerNr: { public: true, type: 'BIGINT' },
           fFPCode: { public: true, type: 'TEXT' },
           fPrintGroupCode: { public: true, type: 'TEXT' },
           fIntdocnr: { public: true, type: 'BIGINT' },
           fEformCode: { public: true, type: 'TEXT' },
           fTyp: { public: true, type: 'INTEGER' } } } } }