module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fLimitSL: { public: true, type: 'DOUBLE' },
     fLimitPL: { public: true, type: 'DOUBLE' },
     fVATReportDef: { public: true, type: 'TEXT' },
     fObjType: { public: true, type: 'TEXT' } } }