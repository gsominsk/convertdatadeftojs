module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCurncyCode: { public: true, type: 'TEXT' },
     fDate: { public: true, type: 'DATE' },
     fToRate1: { public: true, type: 'DOUBLE' },
     fToRate2: { public: true, type: 'DOUBLE' },
     fFrRate: { public: true, type: 'DOUBLE' },
     fPurchaseRateTo1: { public: true, type: 'DOUBLE' },
     fSalesRateTo1: { public: true, type: 'DOUBLE' } },
  indexes: { CDKeyIndex35: { fields: [ 'fCurncyCode', 'fDate' ], indicesType: 'UNIQUE' } } }