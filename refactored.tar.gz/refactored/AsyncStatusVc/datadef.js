module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fStatus: { public: true, type: 'BIGINT' },
     fErr: { public: true, type: 'BIGINT' },
     fErrmsg: { public: true, type: 'TEXT' },
     fMath: { public: true, type: 'BIGINT' } },
  indexes: { SerNrIndex592: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }