module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fTransNr: { public: true, type: 'BIGINT' },
     fTransDate: { public: true, type: 'DATE' },
     fAccNumber: { public: true, type: 'TEXT' },
     fFileName: { public: true, type: 'TEXT' },
     fIntYc: { public: true, type: 'INTEGER' },
     fRowNr: { public: true, type: 'INTEGER' } },
  indexes: 
   { MainKeyIndex431: 
      { fields: 
         [ 'fAccNumber',
           'fTransDate',
           'fTransNr',
           'fIntYc',
           'fFileName',
           'fRowNr' ],
        indicesType: 'UNIQUE' } } }