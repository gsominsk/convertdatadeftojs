module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fInvNr: { public: true, type: 'BIGINT' },
     fWIPAcc: { public: true, type: 'TEXT' },
     fWIPBalAcc: { public: true, type: 'TEXT' },
     fSum: { public: true, type: 'DOUBLE' },
     fPRCode: { public: true, type: 'TEXT' } },
  indexes: { SerNrIndex669: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }