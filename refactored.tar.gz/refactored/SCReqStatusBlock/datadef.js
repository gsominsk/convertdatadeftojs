module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCompany: { public: true, type: 'INTEGER' },
     fSCCode: { public: true, type: 'TEXT' } } }