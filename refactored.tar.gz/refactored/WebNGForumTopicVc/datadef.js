module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fLastReplyMail: { public: true, type: 'BIGINT' },
     fLastReplyDate: { public: true, type: 'DATE' },
     fLastReplyTime: { public: true, type: 'TIME' },
     fAnsweredFlag: { public: true, type: 'INTEGER' },
     fRootConf: { public: true, type: 'TEXT' },
     fMotherConf: { public: true, type: 'BIGINT' },
     fHidden: { public: true, type: 'INTEGER' } },
  indexes: { SerNrIndex861: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }