module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fVISerNr: { public: true, type: 'BIGINT' },
     fRVal: { public: true, type: 'DOUBLE' },
     fDueDate: { public: true, type: 'DATE' },
     fVECode: { public: true, type: 'TEXT' },
     fCurncyCode: { public: true, type: 'TEXT' },
     fBookRVal: { public: true, type: 'DOUBLE' },
     fInstallNr: { public: true, type: 'BIGINT' } },
  indexes: { VISerNrIndex30: { fields: [ 'fVISerNr', 'fDueDate' ], indicesType: 'UNIQUE' } } }