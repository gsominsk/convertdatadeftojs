module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fModeType: { public: true, type: 'INTEGER' },
     fUserName: { public: true, type: 'TEXT' },
     fPassword: { public: true, type: 'TEXT' },
     fSignature: { public: true, type: 'TEXT' },
     fAddr1: { public: true, type: 'INTEGER' },
     fAddr2: { public: true, type: 'INTEGER' },
     fAddr3: { public: true, type: 'INTEGER' },
     fAddr4: { public: true, type: 'INTEGER' },
     fAddr5: { public: true, type: 'INTEGER' } } }