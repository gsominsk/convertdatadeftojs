module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fComment: { public: true, type: 'TEXT' },
     fMinAge: { public: true, type: 'BIGINT' },
     fMaxAge: { public: true, type: 'BIGINT' },
     fMinPersons: { public: true, type: 'BIGINT' },
     fMaxPersons: { public: true, type: 'BIGINT' },
     fResLoc: { public: true, type: 'TEXT' },
     fClosed: { public: true, type: 'INTEGER' },
     fArtCode: { public: true, type: 'TEXT' } },
  indexes: { CodeIndex673: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }