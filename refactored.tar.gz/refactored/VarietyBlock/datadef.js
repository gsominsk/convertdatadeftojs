module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fOpenVarPaste: { public: true, type: 'INTEGER' },
     fUseInfoFromRow: { public: true, type: 'INTEGER' },
     fAutoNewBarCode: { public: true, type: 'INTEGER' },
     fAutoNewPurItem: { public: true, type: 'INTEGER' },
     fAutoVarietyDef: { public: true, type: 'INTEGER' } } }