module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fCheckSerNr: { public: true, type: 'BIGINT' },
     fCheckNr: { public: true, type: 'TEXT' },
     fOpenf: { public: true, type: 'INTEGER' },
     fStatusDate: { public: true, type: 'DATE' },
     fFileName: { public: true, type: 'TEXT' },
     fTransNr: { public: true, type: 'BIGINT' } },
  indexes: { SerNrIndex809: { fields: [ 'fSerNr' ], indicesType: 'UNIQUE' } } }