module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fTransNr: { public: true, type: 'BIGINT' },
     fTransDate: { public: true, type: 'DATE' },
     fAccNumber: { public: true, type: 'TEXT' },
     fFileName: { public: true, type: 'TEXT' },
     fIntYc: { public: true, type: 'INTEGER' },
     fTransTime: { public: true, type: 'TIME' } },
  indexes: 
   { MainKeyIndex9: 
      { fields: [ 'fAccNumber', 'fTransDate', 'fTransNr', 'fIntYc', 'fFileName' ],
        indicesType: 'UNIQUE' } } }