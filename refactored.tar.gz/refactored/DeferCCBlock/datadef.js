module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fUntilDate: { public: true, type: 'DATE' },
     fUntilTime: { public: true, type: 'TIME' } } }