module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     CDVcMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fItem: { public: true, type: 'TEXT' },
           fPrice: { public: true, type: 'DOUBLE' },
           fDiscount: { public: true, type: 'DOUBLE' },
           fTimeClass: { public: true, type: 'TEXT' } } },
     fCustCode: { public: true, type: 'TEXT' },
     fCustName: { public: true, type: 'TEXT' } },
  indexes: { CustCodeIndex90: { fields: [ 'fCustCode' ], indicesType: 'UNIQUE' } } }