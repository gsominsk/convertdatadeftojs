module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSignature: { public: true, type: 'TEXT' },
     fProtVer: { public: true, type: 'BIGINT' },
     fName: { public: true, type: 'TEXT' },
     fProduct: { public: true, type: 'BIGINT' },
     fStatus: { public: true, type: 'BIGINT' },
     fStartDate: { public: true, type: 'DATE' },
     fStartTime: { public: true, type: 'TIME' } },
  indexes: 
   { MainKeyIndex558: 
      { fields: [ 'fSignature', 'fProtVer', 'fProduct' ],
        indicesType: 'UNIQUE' } } }