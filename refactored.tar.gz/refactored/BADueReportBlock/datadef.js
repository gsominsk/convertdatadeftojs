module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fMailbox: { public: true, type: 'TEXT' },
     fTransTime: { public: true, type: 'TIME' } } }