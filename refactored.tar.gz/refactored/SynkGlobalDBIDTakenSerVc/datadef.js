module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fDBIDCode: { public: true, type: 'TEXT' },
     fFileName: { public: true, type: 'TEXT' },
     fFrom: { public: true, type: 'BIGINT' },
     fTo: { public: true, type: 'BIGINT' },
     fLastNumber: { public: true, type: 'BIGINT' } },
  indexes: 
   { DBIDCodeIndex820: 
      { fields: [ 'fDBIDCode', 'fFileName', 'fFrom' ],
        indicesType: 'UNIQUE' } } }