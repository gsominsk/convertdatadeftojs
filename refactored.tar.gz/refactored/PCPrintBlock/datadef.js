module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fRowsPerPage: { public: true, type: 'BIGINT' },
     fPageBreakLines: { public: true, type: 'BIGINT' } } }