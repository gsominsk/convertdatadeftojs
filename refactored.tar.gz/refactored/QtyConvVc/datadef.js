module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fCode: { public: true, type: 'TEXT' },
     fQuantity: { public: true, type: 'BIGINT' },
     fComment: { public: true, type: 'TEXT' } },
  indexes: { CodeIndex314: { fields: [ 'fCode' ], indicesType: 'UNIQUE' } } }