module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fLeadActType: { public: true, type: 'TEXT' },
     fIdeaActType: { public: true, type: 'TEXT' },
     fQuoteClass: { public: true, type: 'TEXT' } } }