module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fProject: { public: true, type: 'TEXT' },
     fItem: { public: true, type: 'TEXT' },
     fPOSerNr: { public: true, type: 'BIGINT' },
     fPOQty: { public: true, type: 'DOUBLE' },
     fPOVal: { public: true, type: 'DOUBLE' },
     fTransDate: { public: true, type: 'DATE' } },
  indexes: 
   { ProjectIndex181: 
      { fields: [ 'fProject', 'fItem', 'fPOSerNr' ],
        indicesType: 'UNIQUE' } } }