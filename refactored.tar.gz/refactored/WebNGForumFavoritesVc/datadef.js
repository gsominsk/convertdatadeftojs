module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     fCustCode: { public: true, type: 'TEXT' },
     fRecType: { public: true, type: 'INTEGER' } },
  indexes: 
   { SerNrIndex863: 
      { fields: [ 'fCustCode', 'fSerNr', 'fRecType' ],
        indicesType: 'UNIQUE' } } }