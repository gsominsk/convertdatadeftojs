module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fQuant: { public: true, type: 'DOUBLE' },
     fItem: { public: true, type: 'TEXT' },
     fSerial: { public: true, type: 'TEXT' },
     fLocation: { public: true, type: 'TEXT' },
     fCostPrice: { public: true, type: 'DOUBLE' } },
  indexes: 
   { MainKeyIndex373: 
      { fields: [ 'fItem', 'fLocation', 'fSerial' ],
        indicesType: 'UNIQUE' } } }