module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fServerIP: { public: true, type: 'TEXT' },
     fServerPort: { public: true, type: 'BIGINT' },
     fCustID: { public: true, type: 'TEXT' },
     fPassword: { public: true, type: 'TEXT' },
     fIncoming: { public: true, type: 'BIGINT' },
     fOutgoing: { public: true, type: 'BIGINT' } } }