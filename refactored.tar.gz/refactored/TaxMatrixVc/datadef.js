module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fSerNr: { public: true, type: 'BIGINT' },
     TaxMatrixVcMatrix: 
      { public: true,
        type: 'MATRIX',
        label: 'Math',
        fields: 
         { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
           fVATCode: { public: true, type: 'TEXT' },
           fVATSum: { public: true, type: 'DOUBLE' },
           fVATRate: { public: true, type: 'DOUBLE' },
           fBaseSum: { public: true, type: 'DOUBLE' },
           fCalcBase: { public: true, type: 'INTEGER' } } },
     fRoundVal: { public: true, type: 'DOUBLE' } } }