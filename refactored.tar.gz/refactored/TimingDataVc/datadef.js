module.exports = { fields: 
   { id: { type: 'INTEGER', autoIncrement: true, primaryKey: true },
     fUserCode: { public: true, type: 'TEXT' },
     fDate: { public: true, type: 'DATE' },
     fTime: { public: true, type: 'TIME' },
     fLength: { public: true, type: 'BIGINT' },
     fTransactions: { public: true, type: 'BIGINT' },
     fTimeInServer: { public: true, type: 'BIGINT' },
     fServerWait: { public: true, type: 'BIGINT' },
     fNetworkTime: { public: true, type: 'BIGINT' } },
  indexes: 
   { UserCodeIndex527: 
      { fields: [ 'fUserCode', 'fDate', 'fTime' ],
        indicesType: 'UNIQUE' } } }